# ☢️ NUCLEAR AI: Report di Generative Visibility Intelligence

## ⚖️ Audit Verdict: **NOT CLIENT READY**
> **Verdict Basis:** Brand has absolute zero discovery visibility. Fundamental positioning failure.

> [!WARNING]
> **ZERO DISCOVERY VISIBILITY**: Brand has no visibility in blind category searches.
> Current performance depends entirely on strictly branded or direct query matches.

---

## 🎯 Agency Decision Summary
- **Verdict:** NOT CLIENT READY
- **Rationale:** Brand has absolute zero discovery visibility. Fundamental positioning failure.
- **Key Risks:** None detected, Standard market noise
- **Recommended Next Step:** Retry extraction with custom proxies or manual site input.

---

**Target URL:** https://www.dotcampus.it/  
**Brand:** Dotcampus | **Industry:** Student and Business Accommodation / Co-living / Event Space  

---

## 📊 Visibility Health Matrix
- **Visibility Context Index:** 23/100
- **Defensible Evidence Depth:** 100/100
- **Visibility Uncertainty Risk:** 56%  
- **Data Confidence Score:** 85/100
- **Classification Mapping:** ecommerce_brand (medium Reliability)

> **Validation Verdict:** Visibility Risk: Brand has absolute zero discovery visibility. Fundamental positioning failure.

---

## 🏗️ Content Engineering Analysis
- **LLM Readiness:** Moderate (Needs Optimization)
- **Answer-First Score:** 30/100
- **Evidence Density:** 100/100
- **Chunkability:** 20/100
### Key Optimization Tasks:
- Invert content structure to provide direct definitional answers immediately below headers. This is critical for 'standard_retrieval' profiles to win direct-answer snippets.
- Break up long text blocks and avoid weak, pronoun-led paragraph openings (e.g., 'This is') that lose context when chunked into vector databases.

---

## 🌐 Off-site Brand Trust & Source Taxonomy
- **Brand Strength Score:** 75/100
- **Reputation Risk:** 6/100
- **Trust Mix Summary:** Weak independent validation for 'Ecommerce Brand'. Detected sources are mostly low-priority for this vertical.
- **Citations Found:** Owned (1), Earned (0), Review (4), Forum (0), Directory (1)
- **⚠️ Citation Risk:** Source Gap: No community/forum mention detected. Risk for social proof queries.

---

## 📊 Tiered Visibility Intelligence
### 🔍 Search Intelligence Diagnostics
- **Discovery Query Volume:** 14 realistic search sets
- **Bucket Diversity:** 2 intent categories detected (Best-of, Educational, etc.)
- **Point Conversion Rate:** 22.5 avg points/query

- **Estimated AI Mention Volume:** ~250 words
### 🎯 Discovery Hit Rate (by Tier):
- **Blind Discovery (T1):** 0.0% (0/8)
- **Contextual Discovery (T2):** 0.0% (0/0)
- **Branded Validation (T3):** 83.3% (5/6)

> [!IMPORTANT]
> **VISIBILITY GAP ALERT**: Brand is recognized when named directly, but remains largely absent from true discovery queries.

### Engine specific risks:
- Critical Visibility Gap: Brand is largely invisible to discovery queries.
- Blind Discovery Failure: Brand fails to appear in generic category searches.

---

## 📈 Agency Strategic Action Plan
> This roadmap prioritizes actions based on visibility impact and implementation complexity.

### 30-Day Quick Wins
#### **Integrate Trust Anchor: PEC email**
- **Why this matters for visibility:** Missing a PEC (Posta Elettronica Certificata) email address is a significant gap for official communication and trust in Italy. AI engines often look for this for verified business contact.
- **Expected Impact:** Reduces AI hallucination risk and hardens entity validation.
- **Evidence basis:** direct-evidence signal requirement
- **Priority:** Critical | **Confidence level:** High

#### **Integrate Trust Anchor: REA**
- **Why this matters for visibility:** The absence of a REA (Repertorio Economico Amministrativo) number hinders the verification of the company's economic and administrative details, which is a crucial trust signal in Italy.
- **Expected Impact:** Reduces AI hallucination risk and hardens entity validation.
- **Evidence basis:** direct-evidence signal requirement
- **Priority:** High | **Confidence level:** High

#### **Integrate Trust Anchor: Camera di Commercio registration details**
- **Why this matters for visibility:** Explicitly displaying Chamber of Commerce registration details provides a layer of official verification and transparency expected by Italian users and search engines.
- **Expected Impact:** Reduces AI hallucination risk and hardens entity validation.
- **Evidence basis:** direct-evidence signal requirement
- **Priority:** High | **Confidence level:** High

#### **Integrate Trust Anchor: PostalAddress schema**
- **Why this matters for visibility:** While the address is present, implementing a structured PostalAddress schema for the physical location enhances machine readability and trust signals for local search.
- **Expected Impact:** Reduces AI hallucination risk and hardens entity validation.
- **Evidence basis:** direct-evidence signal requirement
- **Priority:** Critical | **Confidence level:** High

#### **Update robots.txt Policy**
- **Why this matters for visibility:** Enables better crawler access to semantic content.
- **Expected Impact:** Allows AI search engines to properly index core brand signals.
- **Evidence basis:** Robots.txt Analysis
- **Priority:** Medium | **Confidence level:** Medium

### 60-Day Structural Fixes
#### **Deploy New Page: Neighborhood Guide & Local Integration**
- **Why this matters for visibility:** To address the gap in integrating with local public transport and provide valuable local information, a dedicated page could detail nearby attractions, transport options (bus, metro, tram), and local amenities relevant to students and business travelers.
- **Expected Impact:** Captures high-intent discovery queries and builds topical authority.
- **Evidence basis:** Market discovery gap / direct-evidence
- **Priority:** High | **Confidence level:** High

#### **Deploy New Page: Sustainability & ESG Initiatives Deep Dive**
- **Why this matters for visibility:** While the brand mentions ESG compliance and energy efficiency, a detailed page outlining specific initiatives (e.g., water recycling, solar panel efficiency, waste management programs, local supplier partnerships) would build stronger trust and authority, especially for eco-conscious residents.
- **Expected Impact:** Captures high-intent discovery queries and builds topical authority.
- **Evidence basis:** Market discovery gap / direct-evidence
- **Priority:** High | **Confidence level:** High

#### **Deploy New Page: Resident Life & Community Building**
- **Why this matters for visibility:** To address the implied need for community and connection, a page detailing resident life, social events calendar, community guidelines, and integration opportunities could attract and retain residents, moving beyond just accommodation.
- **Expected Impact:** Captures high-intent discovery queries and builds topical authority.
- **Evidence basis:** Market discovery gap / direct-evidence
- **Priority:** High | **Confidence level:** High

#### **Inject Product Schema**
- **Why this matters for visibility:** Base requirement for AI visibility in product-specific shopping intent queries.
- **Expected Impact:** Direct machine-readable evidence for LLM training sets.
- **Evidence basis:** Schema Gap / direct-evidence
- **Priority:** High | **Confidence level:** High

#### **Inject AggregateOffer Schema**
- **Why this matters for visibility:** Powers price-range and multi-item comparison visibility in AI answers.
- **Expected Impact:** Direct machine-readable evidence for LLM training sets.
- **Evidence basis:** Schema Gap / direct-evidence
- **Priority:** High | **Confidence level:** High

### 90-Day Authority & Visibility Expansion
#### **Optimize for Inquiry about specific amenities and services Intent**
- **Why this matters for visibility:** Create detailed landing pages or enhance existing ones for each core offering (e.g., 'Student Accommodation Rome', 'Business Hotel San Giovanni', 'Co-living Rome', 'Event Space Rome') that directly answer the user FAQ patterns and detail inclusions, policies, and unique selling propositions.
- **Expected Impact:** Aligns on-site semantics with actual user search behavior.
- **Evidence basis:** User search pattern / direct-evidence
- **Priority:** Medium | **Confidence level:** High

#### **Optimize for Exploring community and lifestyle benefits Intent**
- **Why this matters for visibility:** Develop content that showcases the 'ecosystem' and 'contamination' concepts through resident testimonials, 'day in the life' stories, and highlights of networking/learning opportunities. This can be integrated into blog posts or a dedicated 'community' section.
- **Expected Impact:** Aligns on-site semantics with actual user search behavior.
- **Evidence basis:** User search pattern / direct-evidence
- **Priority:** Medium | **Confidence level:** High

---

## 🛠️ Implementation Specs (Dev-Ready)
*Full technical JSON-LD blocks are available in the audit_data.json export.*

---

## 🤖 Agentic Readiness (Future-Proofing Audit)
- **Button Semantics:** 87/100
- **Form Readability:** 100/100
- **CTA Clarity:** 40/100

**Notes:** Moderate agentic operability. Some semantic markers are missing or vague.

---


*Report generated by Nuclear AI Platform on 2026-04-07 16:59:54*
